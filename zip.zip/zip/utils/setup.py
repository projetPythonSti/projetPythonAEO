from pygame.examples.grid import TILE_SIZE

TILE_SIZE = 64