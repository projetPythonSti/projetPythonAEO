import io
import sys
import timeit
from collections import defaultdict
from datetime import datetime
import time
import re

from models.Exceptions import PathfindingException
from models.Pathfinding import Pathfinding
from models.Position import Position
from models.World import World
from models.buildings.buildings import Building
from models.unity.Unity import Unity

gmOutput = io.StringIO()

class GameManager:


        """
            26/12/2024@tahakhetib : J'ai apporté les modifications suivantes
                - Adaptation de la fonction moveUnit() pour que celle-ci fasse bien bouger les unités sur la carte
            01/01/2025@tahakhetib : J'ai apporté les modifications suivantes
                - Corrigé le code de singe que j'ai écrit

        """
        tick = timeit.default_timer()
        unitToMove = defaultdict(dict)
        '''
            Syntaxe du dictionnaire
            { 
                idUnité | idGroup : {
                            group : [idUnité1, idUnité2, idUnité3, idUnité4, idUnité5, idUnité6] // Si nous sommes dans le cadre d'un groupe d'unité à déplacer
                            moveQueue : [(0,1),  (0,2),  (1,2)] // représente la file des positions à suivre pour atteindre la destination
                            nextTile : (0,2) // représente la prochaine tuile dans laquelle doit se trouver le personnage (nécessaire car les personnages se déplacent à moins d'une tuile par seconde
                            currentPos : (0,2) // Représente la position actuelle
                           }
            } 
                    
        '''
        def __init__(self, speed, world: World,debug=False, writeToDisk=False ):
            self.gameSpeed = speed
            self.world = world
            self.debug = debug
            self.writeToDisk = writeToDisk
            self.save = False

        def logger(self, *args, **kwargs):
            if self.debug:
                if self.writeToDisk:
                    sys.stdout = gmOutput
                    print(*args, **kwargs)
                    sys.stdout = sys.__stdout__
                else:
                    print(*args, **kwargs)
        def getTeamNumber(self, name):
            pattern = r'\d+'
            substrings = re.findall(pattern, name)
            #print(substrings) #prints the subStrings extracted from the unitName
            return int(substrings[0])


        def moveUnit(self, uid):
            deltaTime = timeit.default_timer() - self.tick
            unit = self.unitToMove[uid]
            unit["timeElapsed"] += deltaTime.real
            # self.logger("time elapsed : ", unit["timeElapsed"])
            if unit["timeElapsed"] >= (unit["timeToTile"]):
                self.world.tiles_dico[unit["moveQueue"][0]].set_contains(None)
                try:
                    self.world.filled_tiles.pop(unit["moveQueue"][0])
                except KeyError:
                    self.logger(f"Attempted to remove non-existing tile at {unit['moveQueue'][0]}")
                unit["moveQueue"] = unit["moveQueue"][1::]
                
                # Check if the unit's type and UID exist in the community
                team_index = unit["team"] - 1
                unit_type = unit["type"].lower()
                
                # Ensure team_index is within range
                if team_index < 0 or team_index >= len(self.world.villages):
                    self.logger(f"Invalid team index: {team_index} for unit UID '{uid}'")
                    return
                
                village = self.world.villages[team_index]
                
                if unit_type in village.community:
                    if uid in village.community[unit_type]:
                        unitObj = village.community[unit_type][uid]
                    else:
                        self.logger(f"Unit UID '{uid}' not found in community of type '{unit_type}'")
                        return
                else:
                    self.logger(f"Unit type '{unit_type}' not found in village community")
                    return

                unitObj.position = Position(unit["moveQueue"][0][0], unit["moveQueue"][0][1])
                self.world.tiles_dico[unit["moveQueue"][0]].set_contains(unitObj)
                self.logger("GameManager | moveUnit----- Infos on the nextTile to the next tile :", (unit["moveQueue"][0]))
                self.world.filled_tiles[unit["moveQueue"][0]] = unit["moveQueue"][0]
                unit["currentTile"] = unit["moveQueue"][0]
                unit["timeElapsed"] = 0
                if (len(unit["moveQueue"]) < 2):
                    unit["moveQueue"] = []
                else:
                    unit["nextTile"] = unit["moveQueue"][1]

        def buiding_process(self, building):
            building.begin_building()
            self.time_elapse[building.uid] = 0
            begin_time = timeit.default_timer() - self.tick
            self.time_elapse += begin_time
            begin_time_seconds = self.time_elapse[building.uid] / timeit.default_timer().resolution

            if begin_time_seconds >= building.time_building:
                self.world.tiles_dico[(building.position.getX(), building.position.getY())].set_contains(building)

            #reshow the world here, because le buiding is finish to be built



        def checkUnitsToMove(self):
            if len(self.unitToMove) == 0:
                pass
                #print("No unit to move")
            else:
                unitToDelete = ""
                for k in self.unitToMove:
                    if self.unitToMove[k]["moveQueue"] == []:
                        unitToDelete = k
                    else:
                        self.moveUnit(k)
                if unitToDelete != "":
                    self.unitToMove.pop(unitToDelete)


        def addUnitToMoveDict(self, unit : Unity, destination : Position):
            if unit.position.toTuple() not in self.world.filled_tiles.values():
                self.world.filled_tiles[unit.position.toTuple()] = unit.position.toTuple()
            grid = self.world.convertMapToGrid()
            teamNumber = self.getTeamNumber(unit.uid)
            pathFinding  = Pathfinding(mapGrid=grid, statingPoint= unit.position.toTuple(), goal=destination.toTuple(), debug=False)
            path = pathFinding.astar()
            if path.__class__ == bool:
                raise PathfindingException(self.world.tiles_dico[destination.toTuple()])
                #  : AJOUTER UNE EXCEPTION QUAND IL NE TROUVE VRAIMENT PAS DE CHEMIN
                #self.logger("Found no short path")
            path = path + [pathFinding.startingPoint]
            path = path[::-1]
            self.logger("Unit ADDED TO MOVE DICT")
            self.unitToMove[unit.uid] = {
                "group"     : [],
                "timeToTile" : 1/(unit.speed),
                "timeElapsed" : 0,
                "nextTile" : path[1],
                "currentTile": path[0],
                "estimatedPos" : path[0],
                "team": teamNumber,
                "type" : unit.name,
                "moveQueue": path,
                "destination": Position(destination.getX(), destination.getY())
            }

        def pause(self):
            self.html_generator()

            # def play(self):
            #     datas = self.load_from_file()
            #     if datas:
            #         self.world = datas[0]

        def save_world(self, path=None):
            self.save.save(self.world, path)

        def load_from_file(self, path=None):
            data = self.save.load(path)
            # print("data", data)
            self.world = data[0]

        def html_generator(self):
            village1, village2 = self.world.villages
            #iterating on 2 dict at the same time

            body = f"""
            <!DOCTYPE html>
            <html lang="fr">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Game Stats</title>
            </head>
            <body>
                <h1>Welcome to the Game</h1>
                <p>You made a pause, so here are current information about the world</p>
                <ul>
                
            """
            for pop1, pop2 in zip(village1.population().values(), village2.population().values()):
                for v1, v2 in zip(pop1.values(), pop2.values()):
                    body += f"""
                    <li>Unit {v2.__class__} is at position ({v2.position.getX()}, {v2.position.getY()}) and his life is {v2.health}</li>
                    <li>Unit {v1.__class__} is at position ({v1.position.getX()}, {v1.position.getY()}) and his life is {v1.health}</li>
                    """
            body += """ 
                </ul> 
                </body>
                </html>
            """

            with open("./utils/html/gameStats.html", "w") as file:
                file.write(body)


if __name__ == "__main__":
    pass

